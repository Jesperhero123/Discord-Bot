# BlockBye Discord Bot

A comprehensive Discord bot designed with a modern web dashboard for powerful server management, moderation, and engaging features.

## Features

### 🛡️ Moderation
- **Auto Moderation**: Automatically detect and handle spam, inappropriate content, and rule violations
- **Anti-Spam**: Configurable spam detection with customizable actions
- **Anti-Links**: Block unwanted links with whitelist support
- **Banned Words**: Custom word filtering with role and channel exceptions
- **Moderation Commands**: Warn, kick, ban, timeout, and purge commands

### 🎫 Ticket System
- **Multi-Category Support**: Organize tickets by categories (Billing, Support, etc.)
- **Auto Transcripts**: Automatically save ticket conversations
- **Role Permissions**: Configure which roles can manage tickets
- **Cooldown Protection**: Prevent ticket spam with configurable cooldowns

### 🎉 Giveaways
- **Flexible Entry Methods**: Button clicks or reaction-based entries
- **Custom Duration**: Set any duration for giveaways
- **Winner Selection**: Automatic winner selection with reroll support
- **Role Requirements**: Restrict entries to specific roles

### 📊 Leveling System
- **XP Tracking**: Track user activity and award XP
- **Level Rewards**: Automatic role rewards for reaching levels
- **Leaderboards**: Server-wide leaderboards
- **Customizable Rates**: Adjust XP rates and cooldowns

### 🎮 Games & Fun
- **Snake Game**: Classic snake game in Discord
- **Tic-Tac-Toe**: Play against other users
- **Coin Flip**: Simple coin flip game
- **Statistics**: Track game performance and leaderboards

### 🔧 Utilities
- **Embed Builder**: Create custom embeds with live preview
- **Reaction Roles**: Automatic role assignment via reactions
- **Polls**: Create interactive polls
- **Reminders**: Set personal reminders
- **Broadcasts**: Send announcements to multiple channels

### 📈 Analytics
- **Real-time Stats**: Live server statistics
- **Command Usage**: Track most used commands
- **User Activity**: Monitor user engagement
- **Charts & Graphs**: Visual analytics dashboard

## Installation

### Prerequisites
- Node.js 18.0.0 or higher
- MongoDB database
- Discord Bot Token

### Setup

1. **Clone the repository**
git clone https://github.com/your-username/blockbye-bot.git
cd blockbye-bot
2. **Install dependencies**
npm install
3. **Configure environment variables**
cp .env.example .env
Edit the `.env` file with your configuration:
- `DISCORD_TOKEN`: Your Discord bot token
- `DISCORD_CLIENT_ID`: Your Discord application client ID
- `DISCORD_CLIENT_SECRET`: Your Discord application client secret
- `MONGODB_URI`: Your MongoDB connection string
- `DASHBOARD_URL`: Your dashboard URL (e.g., http://localhost:3000)

4. **Deploy slash commands**
npm run deploy
5. **Start the bot**
npm start
6. **Start the dashboard** (in a separate terminal)
npm run dashboard
## Development

### Running in development mode
# Bot with auto-restart
npm run dev

# Dashboard with auto-restart
npm run dev-dashboard
### Project Structure
src/
├── bot.js              # Main bot file
├── config/             # Configuration files
├── commands/           # Slash commands
├── events/             # Discord events
├── models/             # Database models
├── dashboard/          # Web dashboard
│   ├── server.js       # Dashboard server
│   ├── views/          # EJS templates
│   └── public/         # Static files
└── utils/              # Utility functions
## Dashboard Features

### 🌐 Modern Web Interface
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Real-time Updates**: Live synchronization with Discord
- **Dark Theme**: Beautiful dark theme with gradients
- **Interactive Components**: Toggle switches, live previews, and more

### ⚙️ Easy Configuration
- **Visual Settings**: Configure all bot features through the web interface
- **Live Preview**: See changes before applying them
- **Bulk Actions**: Configure multiple settings at once
- **Import/Export**: Save and share configurations

### 📊 Advanced Analytics
- **Real-time Charts**: Live data visualization
- **Historical Data**: Track changes over time
- **Export Reports**: Generate PDF reports
- **Custom Metrics**: Create custom analytics dashboards

## Commands

### General Commands
- `/help` - Show all available commands
- `/ping` - Check bot latency
- `/serverinfo` - Show server information
- `/userinfo` - Show user information

### Moderation Commands
- `/warn <user> [reason]` - Warn a user
- `/kick <user> [reason]` - Kick a user
- `/ban <user> [reason]` - Ban a user
- `/timeout <user> <duration> [reason]` - Timeout a user
- `/purge <amount>` - Delete messages

### Fun Commands
- `/snake` - Play snake game
- `/tictactoe <user>` - Play tic-tac-toe
- `/coinflip` - Flip a coin
- `/8ball <question>` - Ask the magic 8-ball

### Utility Commands
- `/embed` - Create custom embeds
- `/poll <question>` - Create a poll
- `/reminder <time> <message>` - Set a reminder
- `/level [user]` - Check level and XP
- `/leaderboard` - Show server leaderboard

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- **Discord Server**: [Join our support server](https://discord.gg/your-server)
- **Documentation**: [Read the docs](https://docs.blockbye.com)
- **Issues**: [Report bugs](https://github.com/your-username/blockbye-bot/issues)

## Roadmap

- [ ] Voice channel management
- [ ] Advanced economy system
- [ ] Custom commands builder
- [ ] Multi-language support
- [ ] Plugin system
- [ ] Advanced logging
- [ ] Backup and restore
- [ ] API endpoints
- [ ] Mobile app

---

Made with ❤️ by [Codella](https://github.com/codella)