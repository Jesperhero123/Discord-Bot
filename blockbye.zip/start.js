const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Starting BlockBye Bot and Dashboard...\n');

// Start the Discord bot
const bot = spawn('node', ['src/bot.js'], {
  stdio: 'inherit',
  cwd: __dirname
});

// Start the dashboard server
const dashboard = spawn('node', ['src/dashboard/server.js'], {
  stdio: 'inherit',
  cwd: __dirname
});

// Handle bot process events
bot.on('error', (error) => {
  console.error('❌ Bot process error:', error);
});

bot.on('exit', (code) => {
  console.log(`🤖 Bot process exited with code ${code}`);
  if (code !== 0) {
    console.log('🔄 Restarting bot...');
    // Restart bot logic can be added here
  }
});

// Handle dashboard process events
dashboard.on('error', (error) => {
  console.error('❌ Dashboard process error:', error);
});

dashboard.on('exit', (code) => {
  console.log(`🌐 Dashboard process exited with code ${code}`);
  if (code !== 0) {
    console.log('🔄 Restarting dashboard...');
    // Restart dashboard logic can be added here
  }
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down BlockBye...');
  
  bot.kill('SIGINT');
  dashboard.kill('SIGINT');
  
  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down BlockBye...');
  
  bot.kill('SIGTERM');
  dashboard.kill('SIGTERM');
  
  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

console.log('✅ BlockBye is starting up...');
console.log('🤖 Bot: Starting Discord bot...');
console.log('🌐 Dashboard: Starting web dashboard...');
console.log('\nPress Ctrl+C to stop both services.\n');