const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const config = require('../config/config');
const Guild = require('../models/Guild');
const User = require('../models/User');
const Analytics = require('../models/Analytics');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: config.dashboard.url,
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Session configuration
app.use(session({
  secret: config.dashboard.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true in production with HTTPS
}));

// Passport configuration
app.use(passport.initialize());
app.use(passport.session());

passport.use(new DiscordStrategy({
  clientID: config.discord.clientId,
  clientSecret: config.discord.clientSecret,
  callbackURL: config.discord.callbackURL,
  scope: ['identify', 'guilds']
}, async (accessToken, refreshToken, profile, done) => {
  try {
    let user = await User.findOne({ userId: profile.id });
    
    if (!user) {
      user = new User({
        userId: profile.id,
        username: profile.username,
        discriminator: profile.discriminator,
        avatar: profile.avatar,
        dashboardAccess: true
      });
    } else {
      user.username = profile.username;
      user.discriminator = profile.discriminator;
      user.avatar = profile.avatar;
      user.lastLogin = new Date();
    }
    
    await user.save();
    return done(null, user);
  } catch (error) {
    return done(error, null);
  }
}));

passport.serializeUser((user, done) => {
  done(null, user.userId);
});

passport.deserializeUser(async (userId, done) => {
  try {
    const user = await User.findOne({ userId });
    done(null, user);
  } catch (error) {
    done(error, null);
  }
});

// Middleware to check authentication
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/login');
};

// Routes
app.get('/', (req, res) => {
  if (req.isAuthenticated()) {
    res.redirect('/dashboard');
  } else {
    res.render('index', { user: null });
  }
});

app.get('/login', (req, res) => {
  if (req.isAuthenticated()) {
    res.redirect('/dashboard');
  } else {
    res.render('login');
  }
});

app.get('/auth/discord', passport.authenticate('discord'));

app.get('/auth/discord/callback', 
  passport.authenticate('discord', { failureRedirect: '/login' }),
  (req, res) => {
    res.redirect('/dashboard');
  }
);

app.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      console.error('Logout error:', err);
    }
    res.redirect('/');
  });
});

app.get('/dashboard', isAuthenticated, async (req, res) => {
  try {
    // Get user's guilds with manage permissions
    const userGuilds = await getUserGuilds(req.user.userId);
    res.render('dashboard', { 
      user: req.user, 
      guilds: userGuilds,
      page: 'dashboard'
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/dashboard/:guildId', isAuthenticated, async (req, res) => {
  try {
    const guildId = req.params.guildId;
    const guild = await Guild.findOne({ guildId });
    
    if (!guild) {
      return res.status(404).send('Guild not found');
    }
    
    // Get analytics data
    const analytics = await Analytics.findOne({ guildId }).sort({ date: -1 });
    
    res.render('guild-dashboard', { 
      user: req.user, 
      guild,
      analytics,
      page: 'guild-dashboard'
    });
  } catch (error) {
    console.error('Guild dashboard error:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/dashboard/:guildId/:module', isAuthenticated, async (req, res) => {
  try {
    const { guildId, module } = req.params;
    const guild = await Guild.findOne({ guildId });
    
    if (!guild) {
      return res.status(404).send('Guild not found');
    }
    
    res.render(`modules/${module}`, { 
      user: req.user, 
      guild,
      page: module
    });
  } catch (error) {
    console.error('Module error:', error);
    res.status(500).send('Internal Server Error');
  }
});

// API Routes
app.post('/api/guild/:guildId/settings', isAuthenticated, async (req, res) => {
  try {
    const guildId = req.params.guildId;
    const settings = req.body;
    
    await Guild.findOneAndUpdate(
      { guildId },
      { $set: settings },
      { new: true, upsert: true }
    );
    
    // Emit real-time update
    io.emit('settingsUpdated', { guildId, settings });
    
    res.json({ success: true, message: 'Settings updated successfully' });
  } catch (error) {
    console.error('Settings update error:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});

app.get('/api/guild/:guildId/analytics', isAuthenticated, async (req, res) => {
  try {
    const guildId = req.params.guildId;
    const analytics = await Analytics.find({ guildId })
      .sort({ date: -1 })
      .limit(30);
    
    res.json(analytics);
  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});

// Helper functions
async function getUserGuilds(userId) {
  // This would typically fetch from Discord API
  // For demo purposes, return mock data
  return [
    {
      id: '123456789',
      name: 'Demo Server',
      icon: null,
      owner: true,
      permissions: ['MANAGE_GUILD']
    }
  ];
}

// Socket.IO for real-time updates
io.on('connection', (socket) => {
  console.log('Dashboard client connected');
  
  socket.on('disconnect', () => {
    console.log('Dashboard client disconnected');
  });
});

// Start server
const PORT = config.dashboard.port;
server.listen(PORT, () => {
  console.log(`🌐 Dashboard server running on ${config.dashboard.url}`);
});

module.exports = { app, server, io };