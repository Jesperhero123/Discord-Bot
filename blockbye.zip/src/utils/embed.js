const { EmbedBuilder } = require('discord.js');
const config = require('../config/config');

class EmbedManager {
  constructor() {
    this.defaultColor = config.bot.color;
    this.colors = {
      success: '#00ff00',
      error: '#ff0000',
      warning: '#ffff00',
      info: '#0099ff',
      primary: this.defaultColor
    };
  }

  create(options = {}) {
    const embed = new EmbedBuilder();
    
    if (options.title) embed.setTitle(options.title);
    if (options.description) embed.setDescription(options.description);
    if (options.color) embed.setColor(options.color);
    if (options.author) embed.setAuthor(options.author);
    if (options.footer) embed.setFooter(options.footer);
    if (options.thumbnail) embed.setThumbnail(options.thumbnail);
    if (options.image) embed.setImage(options.image);
    if (options.timestamp) embed.setTimestamp();
    if (options.fields) {
      options.fields.forEach(field => {
        embed.addFields(field);
      });
    }
    
    return embed;
  }

  success(title, description, options = {}) {
    return this.create({
      title: `✅ ${title}`,
      description,
      color: this.colors.success,
      timestamp: true,
      ...options
    });
  }

  error(title, description, options = {}) {
    return this.create({
      title: `❌ ${title}`,
      description,
      color: this.colors.error,
      timestamp: true,
      ...options
    });
  }

  warning(title, description, options = {}) {
    return this.create({
      title: `⚠️ ${title}`,
      description,
      color: this.colors.warning,
      timestamp: true,
      ...options
    });
  }

  info(title, description, options = {}) {
    return this.create({
      title: `ℹ️ ${title}`,
      description,
      color: this.colors.info,
      timestamp: true,
      ...options
    });
  }

  primary(title, description, options = {}) {
    return this.create({
      title,
      description,
      color: this.colors.primary,
      timestamp: true,
      ...options
    });
  }

  // Specific embeds for common use cases
  commandHelp(command) {
    return this.create({
      title: `📚 Command: ${command.name}`,
      description: command.description,
      color: this.colors.info,
      fields: [
        {
          name: 'Usage',
          value: `\`/${command.name} ${command.usage || ''}\``,
          inline: true
        },
        {
          name: 'Category',
          value: command.category || 'General',
          inline: true
        },
        {
          name: 'Permissions',
          value: command.permissions || 'None',
          inline: true
        }
      ],
      timestamp: true
    });
  }

  moderationAction(action, user, moderator, reason) {
    const actions = {
      warn: { emoji: '⚠️', color: this.colors.warning },
      kick: { emoji: '👢', color: this.colors.error },
      ban: { emoji: '🔨', color: this.colors.error },
      timeout: { emoji: '⏰', color: this.colors.warning },
      unban: { emoji: '🔓', color: this.colors.success }
    };

    const actionData = actions[action] || { emoji: '📝', color: this.colors.info };

    return this.create({
      title: `${actionData.emoji} ${action.charAt(0).toUpperCase() + action.slice(1)}`,
      description: `**User:** ${user.tag} (${user.id})\n**Moderator:** ${moderator.tag}\n**Reason:** ${reason || 'No reason provided'}`,
      color: actionData.color,
      thumbnail: user.displayAvatarURL(),
      timestamp: true
    });
  }

  guildJoin(guild) {
    return this.create({
      title: `✅ Joined ${guild.name}`,
      description: `Thanks for adding ${config.bot.name} to your server!`,
      color: this.colors.success,
      fields: [
        {
          name: 'Server Info',
          value: `**Members:** ${guild.memberCount}\n**Owner:** <@${guild.ownerId}>`,
          inline: true
        },
        {
          name: 'Getting Started',
          value: `Use \`/help\` to see all commands\nVisit our [dashboard](${config.dashboard.url}) for configuration`,
          inline: true
        }
      ],
      thumbnail: guild.iconURL(),
      timestamp: true
    });
  }

  levelUp(user, level, xp) {
    return this.create({
      title: '🎉 Level Up!',
      description: `Congratulations ${user}! You've reached level ${level}!`,
      color: this.colors.success,
      fields: [
        {
          name: 'Current Level',
          value: level.toString(),
          inline: true
        },
        {
          name: 'Total XP',
          value: xp.toString(),
          inline: true
        }
      ],
      thumbnail: user.displayAvatarURL(),
      timestamp: true
    });
  }

  giveawayEnd(prize, winner, participants) {
    return this.create({
      title: '🎉 Giveaway Ended!',
      description: `**Prize:** ${prize}\n**Winner:** ${winner}\n**Participants:** ${participants}`,
      color: this.colors.success,
      timestamp: true
    });
  }

  ticketCreated(user, ticketChannel) {
    return this.create({
      title: '🎫 Ticket Created',
      description: `Your ticket has been created: ${ticketChannel}`,
      color: this.colors.success,
      fields: [
        {
          name: 'What happens next?',
          value: 'A staff member will be with you shortly. Please describe your issue in detail.',
          inline: false
        }
      ],
      timestamp: true
    });
  }
}

module.exports = new EmbedManager();