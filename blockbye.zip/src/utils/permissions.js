const { PermissionsBitField } = require('discord.js');

class PermissionManager {
  constructor() {
    this.requiredPermissions = {
      moderation: [
        PermissionsBitField.Flags.ManageMessages,
        PermissionsBitField.Flags.KickMembers,
        PermissionsBitField.Flags.BanMembers,
        PermissionsBitField.Flags.ModerateMembers
      ],
      tickets: [
        PermissionsBitField.Flags.ManageChannels,
        PermissionsBitField.Flags.ManageRoles,
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages
      ],
      general: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.EmbedLinks,
        PermissionsBitField.Flags.ReadMessageHistory
      ]
    };
  }

  hasPermission(member, permission) {
    return member.permissions.has(permission);
  }

  hasPermissions(member, permissions) {
    return permissions.every(permission => this.hasPermission(member, permission));
  }

  hasModerationPermissions(member) {
    return this.hasPermissions(member, this.requiredPermissions.moderation);
  }

  hasTicketPermissions(member) {
    return this.hasPermissions(member, this.requiredPermissions.tickets);
  }

  hasGeneralPermissions(member) {
    return this.hasPermissions(member, this.requiredPermissions.general);
  }

  canManageGuild(member) {
    return this.hasPermission(member, PermissionsBitField.Flags.ManageGuild);
  }

  isAdmin(member) {
    return this.hasPermission(member, PermissionsBitField.Flags.Administrator);
  }

  isOwner(member) {
    return member.guild.ownerId === member.id;
  }

  hasHigherRole(member1, member2) {
    return member1.roles.highest.position > member2.roles.highest.position;
  }

  canModerate(moderator, target) {
    // Owner can moderate anyone
    if (this.isOwner(moderator)) return true;
    
    // Can't moderate owners
    if (this.isOwner(target)) return false;
    
    // Can't moderate admins unless you're an admin with higher role
    if (this.isAdmin(target) && !this.isAdmin(moderator)) return false;
    
    // Must have higher role
    return this.hasHigherRole(moderator, target);
  }

  getMissingPermissions(member, requiredPermissions) {
    return requiredPermissions.filter(permission => !this.hasPermission(member, permission));
  }

  formatPermissions(permissions) {
    return permissions.map(permission => {
      return permission.toString().replace(/([A-Z])/g, ' $1').trim();
    }).join(', ');
  }

  checkBotPermissions(guild, requiredPermissions) {
    const botMember = guild.members.me;
    const missing = this.getMissingPermissions(botMember, requiredPermissions);
    
    return {
      hasPermissions: missing.length === 0,
      missingPermissions: missing
    };
  }
}

module.exports = new PermissionManager();