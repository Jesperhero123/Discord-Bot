const fs = require('fs');
const path = require('path');

class Logger {
  constructor() {
    this.logDir = path.join(__dirname, '../../logs');
    this.ensureLogDirectory();
  }

  ensureLogDirectory() {
    if (!fs.existsSync(this.logDir)) {
      fs.mkdirSync(this.logDir, { recursive: true });
    }
  }

  getTimestamp() {
    return new Date().toISOString();
  }

  getLogFileName(type) {
    const date = new Date().toISOString().split('T')[0];
    return path.join(this.logDir, `${type}-${date}.log`);
  }

  writeLog(type, level, message, data = null) {
    const timestamp = this.getTimestamp();
    const logEntry = {
      timestamp,
      level,
      message,
      data
    };

    const logLine = `[${timestamp}] [${level.toUpperCase()}] ${message}${data ? ` | Data: ${JSON.stringify(data)}` : ''}\n`;
    
    // Write to file
    const logFile = this.getLogFileName(type);
    fs.appendFileSync(logFile, logLine);
    
    // Also log to console with colors
    this.consoleLog(level, message, data);
  }

  consoleLog(level, message, data) {
    const colors = {
      error: '\x1b[31m',   // Red
      warn: '\x1b[33m',    // Yellow
      info: '\x1b[36m',    // Cyan
      debug: '\x1b[35m',   // Magenta
      success: '\x1b[32m'  // Green
    };

    const reset = '\x1b[0m';
    const color = colors[level] || colors.info;
    
    console.log(`${color}[${level.toUpperCase()}]${reset} ${message}${data ? ` | ${JSON.stringify(data)}` : ''}`);
  }

  // Bot-specific logging methods
  bot(level, message, data) {
    this.writeLog('bot', level, message, data);
  }

  command(level, message, data) {
    this.writeLog('commands', level, message, data);
  }

  event(level, message, data) {
    this.writeLog('events', level, message, data);
  }

  dashboard(level, message, data) {
    this.writeLog('dashboard', level, message, data);
  }

  moderation(level, message, data) {
    this.writeLog('moderation', level, message, data);
  }

  // Convenience methods
  error(message, data) {
    this.bot('error', message, data);
  }

  warn(message, data) {
    this.bot('warn', message, data);
  }

  info(message, data) {
    this.bot('info', message, data);
  }

  debug(message, data) {
    this.bot('debug', message, data);
  }

  success(message, data) {
    this.bot('success', message, data);
  }

  // Clean old logs (keep last 30 days)
  cleanOldLogs() {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    if (fs.existsSync(this.logDir)) {
      const files = fs.readdirSync(this.logDir);
      
      files.forEach(file => {
        const filePath = path.join(this.logDir, file);
        const stats = fs.statSync(filePath);
        
        if (stats.mtime < thirtyDaysAgo) {
          fs.unlinkSync(filePath);
          this.info(`Cleaned old log file: ${file}`);
        }
      });
    }
  }
}

module.exports = new Logger();