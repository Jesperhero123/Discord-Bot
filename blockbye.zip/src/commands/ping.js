const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot latency and response time'),
  
  async execute(interaction) {
    const sent = await interaction.reply({ 
      content: '🏓 Pinging...', 
      fetchReply: true 
    });
    
    const latency = sent.createdTimestamp - interaction.createdTimestamp;
    const apiLatency = Math.round(interaction.client.ws.ping);
    
    const pingEmbed = new EmbedBuilder()
      .setTitle('🏓 Pong!')
      .setDescription(`
        **Bot Latency:** ${latency}ms
        **API Latency:** ${apiLatency}ms
        **Status:** ${apiLatency < 100 ? '🟢 Excellent' : apiLatency < 300 ? '🟡 Good' : '🔴 Poor'}
      `)
      .setColor(config.bot.color)
      .setTimestamp();
    
    await interaction.editReply({ 
      content: '', 
      embeds: [pingEmbed] 
    });
  }
};