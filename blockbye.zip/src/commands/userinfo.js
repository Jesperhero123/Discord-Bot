const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Shows information about a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to get information about')
        .setRequired(false)
    ),
  
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);
    
    const userEmbed = new EmbedBuilder()
      .setTitle(`👤 ${user.tag} User Information`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🆔 User ID', value: user.id, inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '🤖 Bot Account', value: user.bot ? 'Yes' : 'No', inline: true }
      )
      .setColor(config.bot.color)
      .setTimestamp();
    
    if (member) {
      userEmbed.addFields(
        { name: '📅 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: '🎭 Roles', value: member.roles.cache.size > 1 ? member.roles.cache.filter(role => role.name !== '@everyone').map(role => role.toString()).join(', ') : 'No roles', inline: false },
        { name: '🏆 Highest Role', value: member.roles.highest.name, inline: true },
        { name: '💼 Permissions', value: member.permissions.has('Administrator') ? 'Administrator' : 'Member', inline: true }
      );
      
      if (member.nickname) {
        userEmbed.addFields({ name: '📝 Nickname', value: member.nickname, inline: true });
      }
    }
    
    await interaction.reply({ embeds: [userEmbed] });
  }
};