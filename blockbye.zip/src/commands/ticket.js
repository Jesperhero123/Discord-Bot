const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');
const Guild = require('../models/Guild');
const config = require('../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Create a support ticket')
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('The reason for creating the ticket')
        .setRequired(false)
    ),
  
  async execute(interaction) {
    const guildData = await Guild.findOne({ guildId: interaction.guild.id });
    
    if (!guildData || !guildData.tickets.enabled) {
      return interaction.reply({
        content: '❌ Ticket system is not enabled on this server.',
        ephemeral: true
      });
    }
    
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const user = interaction.user;
    
    // Check if user already has a ticket
    const existingTicket = interaction.guild.channels.cache.find(
      channel => channel.name === `ticket-${user.username.toLowerCase()}`
    );
    
    if (existingTicket) {
      return interaction.reply({
        content: `❌ You already have an open ticket: ${existingTicket}`,
        ephemeral: true
      });
    }
    
    try {
      // Create ticket channel
      const ticketChannel = await interaction.guild.channels.create({
        name: `ticket-${user.username.toLowerCase()}`,
        type: ChannelType.GuildText,
        parent: guildData.tickets.category,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: [PermissionsBitField.Flags.ViewChannel]
          },
          {
            id: user.id,
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.ReadMessageHistory
            ]
          },
          {
            id: interaction.client.user.id,
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.ManageChannels
            ]
          }
        ]
      });
      
      // Add support role permissions if configured
      if (guildData.tickets.supportRole) {
        await ticketChannel.permissionOverwrites.create(guildData.tickets.supportRole, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true
        });
      }
      
      // Create ticket embed
      const ticketEmbed = new EmbedBuilder()
        .setTitle('🎫 Support Ticket')
        .setDescription(`**Ticket Creator:** ${user}\n**Reason:** ${reason}\n\nA staff member will be with you shortly. Please describe your issue in detail.`)
        .setColor(config.bot.color)
        .setFooter({ text: 'Click the button below to close this ticket' })
        .setTimestamp();
      
      // Create close button
      const closeButton = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('close-ticket')
            .setLabel('Close Ticket')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('🔒')
        );
      
      await ticketChannel.send({
        content: `${user} ${guildData.tickets.supportRole ? `<@&${guildData.tickets.supportRole}>` : ''}`,
        embeds: [ticketEmbed],
        components: [closeButton]
      });
      
      // Log ticket creation
      if (guildData.tickets.logChannel) {
        const logChannel = interaction.guild.channels.cache.get(guildData.tickets.logChannel);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('📝 Ticket Created')
            .setDescription(`**User:** ${user.tag} (${user.id})\n**Channel:** ${ticketChannel}\n**Reason:** ${reason}`)
            .setColor('#00ff00')
            .setTimestamp();
          
          await logChannel.send({ embeds: [logEmbed] });
        }
      }
      
      await interaction.reply({
        content: `✅ Ticket created successfully! ${ticketChannel}`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('Error creating ticket:', error);
      await interaction.reply({
        content: '❌ An error occurred while creating the ticket.',
        ephemeral: true
      });
    }
  }
};