const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Guild = require('../models/Guild');
const config = require('../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Create a giveaway')
    .addStringOption(option =>
      option.setName('prize')
        .setDescription('The prize for the giveaway')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('duration')
        .setDescription('Duration of the giveaway (e.g., 1h, 30m, 2d)')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('winners')
        .setDescription('Number of winners')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(20)
    )
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel to post the giveaway in')
        .setRequired(false)
    ),
  
  async execute(interaction) {
    const guildData = await Guild.findOne({ guildId: interaction.guild.id });
    
    if (!guildData || !guildData.giveaways.enabled) {
      return interaction.reply({
        content: '❌ Giveaway system is not enabled on this server.',
        ephemeral: true
      });
    }
    
    const prize = interaction.options.getString('prize');
    const duration = interaction.options.getString('duration');
    const winners = interaction.options.getInteger('winners') || 1;
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    
    // Parse duration
    const durationMs = parseDuration(duration);
    if (!durationMs) {
      return interaction.reply({
        content: '❌ Invalid duration format. Use formats like: 1h, 30m, 2d',
        ephemeral: true
      });
    }
    
    const endTime = Date.now() + durationMs;
    
    try {
      // Create giveaway embed
      const giveawayEmbed = new EmbedBuilder()
        .setTitle('🎉 GIVEAWAY 🎉')
        .setDescription(`**Prize:** ${prize}\n**Winners:** ${winners}\n**Ends:** <t:${Math.floor(endTime / 1000)}:R>\n**Hosted by:** ${interaction.user}`)
        .setColor('#ff6b6b')
        .setFooter({ text: 'Click the button below to enter!' })
        .setTimestamp(endTime);
      
      // Create enter button
      const enterButton = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('enter-giveaway')
            .setLabel('Enter Giveaway')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('🎉')
        );
      
      const giveawayMessage = await channel.send({
        embeds: [giveawayEmbed],
        components: [enterButton]
      });
      
      // Set timeout to end giveaway
      setTimeout(async () => {
        await endGiveaway(giveawayMessage, prize, winners);
      }, durationMs);
      
      await interaction.reply({
        content: `✅ Giveaway created successfully in ${channel}!`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('Error creating giveaway:', error);
      await interaction.reply({
        content: '❌ An error occurred while creating the giveaway.',
        ephemeral: true
      });
    }
  }
};

function parseDuration(duration) {
  const regex = /^(\d+)([smhd])$/;
  const match = duration.match(regex);
  
  if (!match) return null;
  
  const amount = parseInt(match[1]);
  const unit = match[2];
  
  const multipliers = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000
  };
  
  return amount * multipliers[unit];
}

async function endGiveaway(message, prize, winnerCount) {
  try {
    // Get all reactions on the giveaway message
    const reaction = message.reactions.cache.get('🎉');
    if (!reaction) return;
    
    const users = await reaction.users.fetch();
    const participants = users.filter(user => !user.bot);
    
    if (participants.size === 0) {
      const noWinnerEmbed = new EmbedBuilder()
        .setTitle('🎉 Giveaway Ended')
        .setDescription(`**Prize:** ${prize}\n**Winner:** No valid entries`)
        .setColor('#ff6b6b')
        .setTimestamp();
      
      await message.edit({ embeds: [noWinnerEmbed], components: [] });
      return;
    }
    
    // Select random winners
    const winners = [];
    const participantArray = Array.from(participants.values());
    
    for (let i = 0; i < Math.min(winnerCount, participantArray.length); i++) {
      const randomIndex = Math.floor(Math.random() * participantArray.length);
      const winner = participantArray.splice(randomIndex, 1)[0];
      winners.push(winner);
    }
    
    const winnerEmbed = new EmbedBuilder()
      .setTitle('🎉 Giveaway Ended')
      .setDescription(`**Prize:** ${prize}\n**Winner(s):** ${winners.map(w => `<@${w.id}>`).join(', ')}\n**Participants:** ${participants.size}`)
      .setColor('#00ff00')
      .setTimestamp();
    
    await message.edit({ embeds: [winnerEmbed], components: [] });
    
    // Send congratulations message
    await message.reply({
      content: `🎉 Congratulations ${winners.map(w => `<@${w.id}>`).join(', ')}! You won **${prize}**!`
    });
    
  } catch (error) {
    console.error('Error ending giveaway:', error);
  }
}