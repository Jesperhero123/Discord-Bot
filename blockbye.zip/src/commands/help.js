const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Shows all available commands and features'),
  
  async execute(interaction) {
    const helpEmbed = new EmbedBuilder()
      .setTitle(`📚 ${config.bot.name} Commands & Features`)
      .setDescription(`
        **🌐 Dashboard**: [Open Dashboard](${config.dashboard.url})
        Configure all bot features through our modern web interface!
        
        **⚙️ General Commands:**
        \`/help\` - Show this help message
        \`/ping\` - Check bot latency
        \`/serverinfo\` - Show server information
        \`/userinfo\` - Show user information
        
        **🛡️ Moderation:**
        \`/warn\` - Warn a user
        \`/kick\` - Kick a user
        \`/ban\` - Ban a user
        \`/timeout\` - Timeout a user
        \`/purge\` - Delete messages
        
        **🎫 Tickets:**
        \`/ticket\` - Create a support ticket
        \`/close\` - Close a ticket
        
        **🎉 Giveaways:**
        \`/giveaway\` - Create a giveaway
        \`/reroll\` - Reroll giveaway winner
        
        **🎮 Games:**
        \`/snake\` - Play snake game
        \`/tictactoe\` - Play tic-tac-toe
        \`/coinflip\` - Flip a coin
        
        **📊 Leveling:**
        \`/level\` - Check your level
        \`/leaderboard\` - Show server leaderboard
        
        **🔧 Utilities:**
        \`/embed\` - Create custom embeds
        \`/poll\` - Create polls
        \`/reminder\` - Set reminders
      `)
      .setColor(config.bot.color)
      .setThumbnail(interaction.client.user.displayAvatarURL())
      .setFooter({ 
        text: `${config.bot.name} • Use the dashboard for full configuration`,
        iconURL: interaction.client.user.displayAvatarURL()
      })
      .setTimestamp();
    
    await interaction.reply({ embeds: [helpEmbed] });
  }
};